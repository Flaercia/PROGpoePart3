/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.progpoe02;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class PROGPOE02 {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        // Registro do usuário
        Registration.registerUser();

        // Login obrigatório
        boolean loggedIn = Login.loginUser();
        if (!loggedIn) {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting...");
            System.exit(0);
        }

        // Definir quantidade de mensagens
        int totalMessages;
        try {
            totalMessages = Integer.parseInt(
                JOptionPane.showInputDialog("How many messages do you want to send?")
            );
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number. Exiting...");
            return;
        }

        ArrayList<Message> sentMessages = new ArrayList<>();

        for (int i = 0; i < totalMessages; i++) {
            String[] options = {
                "Send Messages",
                "Show Recently Sent Messages",
                "Display Sender and Recipient of All Sent Messages",
                "Display Longest Sent Message",
                "Search Message by ID",
                "Search Messages by Recipient",
                "Delete Message by Hash",
                "Display Full Report",
                "Quit"
            };

            int choice = JOptionPane.showOptionDialog(
                null,
                "Select an option:",
                "QuickChat Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
            );

            switch (choice) {
                case 0 -> {
                    Message message = new Message();
                    message.collectMessageData();
                    String result = message.SentMessage();
                    if (result.equals("sent")) {
                        sentMessages.add(message);
                        JOptionPane.showMessageDialog(null, "Message sent successfully! ID: " + message.id);
                        Message.printMessages();
                    } else {
                        JOptionPane.showMessageDialog(null, "Message discarded due to invalid recipient number.");
                    }
                }
                case 1 -> {
                    if (sentMessages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages sent yet.");
                    } else {
                        StringBuilder recentMessages = new StringBuilder("Recently Sent Messages:\n");
                        for (Message msg : sentMessages) {
                            recentMessages.append(msg.toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, recentMessages.toString());
                    }
                }
                case 2 -> Message.showSenderRecipient(sentMessages);
                case 3 -> Message.showLongestMessage(sentMessages);
                case 4 -> {
                    String id = JOptionPane.showInputDialog("Enter Message ID to search:");
                    if (id != null && !id.isEmpty()) {
                        Message.searchMessageByID(sentMessages, id);
                    }
                }
                case 5 -> {
                    String recipient = JOptionPane.showInputDialog("Enter Recipient to search messages for:");
                    if (recipient != null && !recipient.isEmpty()) {
                        Message.searchMessagesByRecipient(sentMessages, recipient);
                    }
                }
                case 6 -> {
                    String hash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
                    if (hash != null && !hash.isEmpty()) {
                        Message.deleteMessageByHash(sentMessages, hash);
                    }
                }
                case 7 -> Message.showFullReport(sentMessages);
                case 8, -1 -> {
                    JOptionPane.showMessageDialog(null, "Total messages sent: " + sentMessages.size());
                    System.exit(0);
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + sentMessages.size());
    }
}