/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.progpoe02;

/**
 *
 * @author RC_Student_lab
 */
public class MessageArrays {

    public static final int MAX_MESSAGES = 100;

    // Arrays principais
    public static String[] sentMessages = new String[MAX_MESSAGES];
    public static String[] sentRecipients = new String[MAX_MESSAGES];
    public static String[] messageIDs = new String[MAX_MESSAGES];
    public static String[] messageHashes = new String[MAX_MESSAGES];

    // Arrays para mensagens classificadas
    public static String[] discardedMessages = new String[MAX_MESSAGES];
    public static String[] storedMessages = new String[MAX_MESSAGES];

    // Índices para controle
    public static int sentIndex = 0;
    public static int storedIndex = 0;
    public static int discardedIndex = 0;
    public static int hashIndex = 0;

    /**
     * Busca uma mensagem pelo ID fornecido.
     * @param id O ID da mensagem.
     * @return A mensagem correspondente ou um aviso de não encontrada.
     */
    public static String searchByMessageID(String id) {
        for (int i = 0; i < sentIndex; i++) {
            if (id.equals(messageIDs[i]) && sentMessages[i] != null) {
                return "Message found:\n" +
                       "Recipient: " + sentRecipients[i] + "\n" +
                       "ID: " + messageIDs[i] + "\n" +
                       "Hash: " + messageHashes[i] + "\n" +
                       "Text: " + sentMessages[i];
            }
        }
        return "Message with ID '" + id + "' not found.";
    }

    /**
     * Adiciona uma nova mensagem nos arrays principais.
     * @param recipient
     * @param message
     * @param id
     * @param hash
     */
    public static void addMessage(String recipient, String message, String id, String hash) {
        if (sentIndex < MAX_MESSAGES) {
            sentRecipients[sentIndex] = recipient;
            sentMessages[sentIndex] = message;
            messageIDs[sentIndex] = id;
            messageHashes[sentIndex] = hash;
            sentIndex++;
            hashIndex++;
        }
    }

    /**
     * Adiciona mensagem ao array de armazenadas.
     * @param message
     */
    public static void storeMessage(String message) {
        if (storedIndex < MAX_MESSAGES) {
            storedMessages[storedIndex++] = message;
        }
    }

    /**
     * Adiciona mensagem ao array de descartadas.
     */
    public static void discardMessage(String message) {
        if (discardedIndex < MAX_MESSAGES) {
            discardedMessages[discardedIndex++] = message;
        }
    }
}