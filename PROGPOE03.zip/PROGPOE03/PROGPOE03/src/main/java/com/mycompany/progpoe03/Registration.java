/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.progpoe02;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;

public class Registration {

    /**
     * This method guides the user through the registration process.
     * It collects and validates the username, password, and cell phone number.
     * Once all inputs are valid, the information is saved to the Login class (simulation).
     */
    public static void registerUser() {
        String username;

        // Loop until a valid username is entered
        do {
            username = JOptionPane.showInputDialog("Register username:");
            if (isValidUsername(username)) {
                JOptionPane.showMessageDialog(null, "Username successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, 
                    "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        } while (true);

        String password;

        // Loop until a valid password is entered
        do {
            password = JOptionPane.showInputDialog("Register password:");
            if (isValidPassword(password)) {
                JOptionPane.showMessageDialog(null, "Password successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, 
                    "Password is not correctly formatted. Please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        } while (true);

        String cellphone;

        // Loop until a valid South African cellphone number is entered
        do {
            cellphone = JOptionPane.showInputDialog("Enter your South African cellphone number with country code (e.g. +27831234567):");
            if (isValidCellNumber(cellphone)) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully added.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, 
                    "Cell phone number is incorrectly formatted or does not contain the international dialing code.");
            }
        } while (true);

        // Simulation: Save data to the Login class (could be replaced with file or JSON storage in a real application)
        Login.correctUsername = username;
        Login.correctPassword = password;
        Login.correctCellNumber = cellphone;

        JOptionPane.showMessageDialog(null, "Registration successful.");
    }

    /**
     * Checks whether the username is valid.
     * It must contain an underscore and be no longer than 5 characters.
     * @param username
     * @return 
     */
    public static boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks whether the password is valid.
     * It must be at least 8 characters long and include:
     * - one uppercase letter
     * - one number
     * - one special character
     * @param password
     * @return 
     */
    public static boolean isValidPassword(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&           // At least one uppercase letter
               password.matches(".*\\d.*") &&             // At least one number
               password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*"); // At least one special character
    }

    /**
     * Checks whether the cellphone number is valid.
     * It must follow the South African international format: +27 followed by 9 digits.
     * @param cell
     * @return 
     */
    public static boolean isValidCellNumber(String cell) {
        return cell.matches("^\\+27\\d{9}$");  // International code + 9 digits
    }
}
