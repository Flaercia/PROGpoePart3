/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.progpoe02;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;

public class Login {

    // These are default login credentials used for simulation/testing purposes.
    public static String correctUsername = "user";
    public static String correctPassword = "pass";

    // Placeholder for the user's registered cellphone number (optional for now).
    public static String correctCellNumber = "";

    // Simulated user name for personalized greeting upon successful login.
    public static String userFirstName = "Flaércia";
    public static String userLastName = "Lopes";

    /**
     * Prompts the user to input their username and password.
     * Verifies the input against stored credentials.
     *
     * @return true if login is successful; false otherwise.
     */
    public static boolean loginUser() {
        // Prompt the user for their username and password using dialog boxes.
        String username;
        username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");

        // Compare input with the predefined username and password.
        if (username.equals(correctUsername) && password.equals(correctPassword)) {
            // If credentials match, show a personalized welcome message.
            JOptionPane.showMessageDialog(null,
                "Welcome " + userFirstName + ", " + userLastName + ", it is great to see you again.");
            return true;
        } else {
            // If credentials are incorrect, show an error message.
            JOptionPane.showMessageDialog(null,
                "Username or password incorrect, please try again.");
            return false;
        }
    }

    static boolean isLoggedIn() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
