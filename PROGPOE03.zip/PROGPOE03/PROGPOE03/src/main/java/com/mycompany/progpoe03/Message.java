package com.mycompany.progpoe02;
import javax.swing.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Message {

    // List to store all messages loaded or created
    public static ArrayList<Message> storedMessages = new ArrayList<>();

    // Message fields
    public String sender;
    public String recipient;
    public String text;
    public String id;
    public String hash;

    // Constructor for creating a new message with recipient and text
    public Message(String recipient, String messageText) {
        this.sender = "System"; // default sender
        this.recipient = recipient;
        this.text = messageText;
        this.id = generateID();
        this.hash = generateHash();
    }

    // Empty constructor used when loading from JSON
    public Message() {}

    // Collect message data from user input dialogs
    public void collectMessageData() {
        sender = JOptionPane.showInputDialog("Enter sender name:");
        recipient = JOptionPane.showInputDialog("Enter recipient phone number (e.g. +27834557896):");
        text = JOptionPane.showInputDialog("Enter message (max 250 characters):");

        if (text != null && text.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message too long! It will be truncated to 250 characters.");
            text = text.substring(0, 250);
        }

        if (sender == null || sender.trim().isEmpty()) {
            sender = "Unknown"; // avoid error in generateID if sender empty
        }

        id = generateID();
        hash = generateHash();
    }

    // Generate a unique message ID based on sender and a random UUID snippet
    private String generateID() {
        String part = (sender.length() >= 2) ? sender.substring(0, 2) : sender;
        return part.toUpperCase() + UUID.randomUUID().toString().substring(0, 5);
    }

    // Generate a hash string for the message (used to delete by hash)
    private String generateHash() {
        return Integer.toHexString((sender + recipient + text).hashCode());
    }

    // Load messages from a JSON file into the storedMessages array list
    public static void loadStoredMessages() {
        storedMessages.clear();
        try {
            @SuppressWarnings("deprecation")
            JSONParser parser = new JSONParser();
            @SuppressWarnings("deprecation")
            JSONArray array = (JSONArray) parser.parse(new FileReader("messages.json"));

            for (Object obj : array) {
                @SuppressWarnings("deprecation")
                JSONObject jsonMsg = (JSONObject) obj;
                Message msg = new Message();
                msg.sender = (String) jsonMsg.get("sender");
                msg.recipient = (String) jsonMsg.get("recipient");
                msg.text = (String) jsonMsg.get("text");
                msg.id = (String) jsonMsg.get("id");
                msg.hash = (String) jsonMsg.get("hash");
                storedMessages.add(msg);
            }
        } catch (IOException | ParseException e) {
            JOptionPane.showMessageDialog(null, "Could not load messages from JSON.");
        }
    }

    // Simulate sending message and return status string ("sent" or "discarded")
    public String SentMessage() {
        // check all conditions before sending
        if (!checkMessageID() || !checkRecipientCell() || text == null || text.length() > 250) {
            return "discarded";
        }
        return "sent";
    }

    // Simulate sending message, checks recipient phone format
    public String sendMessageMenu() {
        return recipient != null && recipient.matches("\\+\\d{11,14}") ? "sent" : "discarded";
    }

    // Display list of senders and recipients in storedMessages
    public static void showSenderRecipient(ArrayList<Message> list) {
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return;
        }
        StringBuilder sb = new StringBuilder("Sender and Recipient List:\n");
        for (Message msg : list) {
            sb.append("From: ").append(msg.sender).append(" | To: ").append(msg.recipient).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Display the longest message text from the list
    public static void showLongestMessage(ArrayList<Message> list) {
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return;
        }
        Message longest = list.get(0);
        for (Message msg : list) {
            if (msg.text.length() > longest.text.length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Message:\n" + longest.text);
    }

    // Search for a message by its unique ID
    public static void searchMessageByID(ArrayList<Message> list, String searchId) {
        for (Message msg : list) {
            if (msg.id.equalsIgnoreCase(searchId)) {
                JOptionPane.showMessageDialog(null, "Message Found:\n" + msg);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No message found with ID: " + searchId);
    }

    // Search for messages by recipient phone number
    public static void searchMessagesByRecipient(ArrayList<Message> list, String searchRecipient) {
        StringBuilder sb = new StringBuilder("Messages to " + searchRecipient + ":\n");
        boolean found = false;
        for (Message msg : list) {
            if (msg.recipient.equalsIgnoreCase(searchRecipient)) {
                sb.append(msg.text).append("\n\n");
                found = true;
            }
        }
        if (found) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + searchRecipient);
        }
    }

    // Delete a message by its hash
    public static void deleteMessageByHash(ArrayList<Message> list, String searchHash) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).hash.equalsIgnoreCase(searchHash)) {
                list.remove(i);
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No message found with that hash.");
    }

    // Show a full report of all messages
    public static void printMessages() {
        showFullReport(storedMessages);
    }

    public static void showFullReport(ArrayList<Message> list) {
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages to display.");
            return;
        }
        StringBuilder sb = new StringBuilder("Full Report of Messages:\n");
        for (Message msg : list) {
            sb.append(msg).append("\n------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Validation methods
    public boolean checkMessageID() {
        return id != null && !id.isEmpty();
    }

    public boolean checkRecipientCell() {
        return recipient != null && recipient.matches("\\+\\d{11,14}");
    }

    public String checkMessageLength() {
        return text != null && text.length() <= 250 ? "Message ready to send." : "Message too long!";
    }

    @Override
    public String toString() {
        return "ID: " + id +
               "\nFrom: " + sender +
               "\nTo: " + recipient +
               "\nMessage: " + text +
               "\nHash: " + hash;
    }

    String createMessageHash() {
        return generateHash();
    }

    void storeMessage() {
        storedMessages.add(this);
    }

    int returnTotalMessages() {
        return storedMessages.size();
    }
}