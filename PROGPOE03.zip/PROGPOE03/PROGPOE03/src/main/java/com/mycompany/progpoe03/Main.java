/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.progpoe02;


/**
 *
 * @author RC_Student_lab
 */
import javax.swing.JOptionPane;

/**
 * Main class of the QuickChat application.
 * Displays a menu for the user to interact with features such as registration, login,
 * sending and managing messages, including JSON handling.
 */
public class Main {

    public static void main(String[] args) {
        // Load stored messages from the JSON file at program startup
        Message.loadStoredMessages();

        int option;

        do {
            String[] menuOptions = {
                "Register User",
                "Login",
                "Send Message",
                "Show Senders and Recipients",
                "Show Longest Sent Message",
                "Search Message by ID",
                "Search Messages by Recipient",
                "Delete Message by Hash",
                "Show Full Report",
                "Reload Messages from JSON",
                "Exit"
            };

            // Display menu and get user's choice
            option = JOptionPane.showOptionDialog(
                    null,
                    "Choose an option:",
                    "QuickChat",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    menuOptions,
                    menuOptions[0]
            );

            switch (option) {
                case 0 -> {
                    // Register a new user
                    Registration.registerUser();
                }

                case 1 -> {
                    // Attempt login
                    boolean loggedIn = Login.loginUser();
                    if (loggedIn) {
                        JOptionPane.showMessageDialog(null, "Login successful.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Login failed. Please check your credentials.");
                    }
                }

                case 2 -> {
                    // Send a new message
                    String recipient = JOptionPane.showInputDialog("Enter recipient number (+country code):");
                    if (recipient == null || recipient.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Recipient number cannot be empty.");
                        break;
                    }

                    String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                    if (messageText == null || messageText.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Message cannot be empty.");
                        break;
                    }

                    Message newMessage = new Message(recipient, messageText);

                    // Validate the message
                    if (!newMessage.checkMessageID()) {
                        JOptionPane.showMessageDialog(null, "Invalid message ID.");
                        break;
                    }
                    if (!newMessage.checkRecipientCell()) {
                        JOptionPane.showMessageDialog(null, "Invalid recipient number format.");
                        break;
                    }
                    String lengthValidation = newMessage.checkMessageLength();
                    if (!lengthValidation.equals("Message ready to send.")) {
                        JOptionPane.showMessageDialog(null, lengthValidation);
                        break;
                    }

                    // Send message and show result
                    String result = newMessage.sendMessageMenu();
                    JOptionPane.showMessageDialog(null, "Result: " + result);
                }

                case 3 -> {
                    // Show senders and recipients of stored messages
                    Message.showSenderRecipient(Message.storedMessages);
                }

                case 4 -> {
                    // Show the longest sent message
                    Message.showLongestMessage(Message.storedMessages);
                }

                case 5 -> {
                    // Search message by ID
                    String id = JOptionPane.showInputDialog("Enter message ID to search:");
                    if (id == null || id.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "ID cannot be empty.");
                        break;
                    }
                    Message.searchMessageByID(Message.storedMessages, id);
                }

                case 6 -> {
                    // Search messages by recipient
                    String recipient = JOptionPane.showInputDialog("Enter recipient number to search messages:");
                    if (recipient == null || recipient.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Recipient number cannot be empty.");
                        break;
                    }
                    Message.searchMessagesByRecipient(Message.storedMessages, recipient);
                }

                case 7 -> {
                    // Delete message by hash
                    String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
                    if (hash == null || hash.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Hash cannot be empty.");
                        break;
                    }
                    Message.deleteMessageByHash(Message.storedMessages, hash);
                }

                case 8 -> {
                    // Show full message report
                    Message.showFullReport(Message.storedMessages);
                }

                case 9 -> {
                    // Reload stored messages from JSON
                    Message.loadStoredMessages();
                    JOptionPane.showMessageDialog(null, "Messages successfully reloaded from JSON file.");
                }

                case 10 -> {
                    // Exit the program
                    JOptionPane.showMessageDialog(null, "Exiting application. Goodbye!");
                }

                default -> {
                    // Handle window close or invalid selection
                    JOptionPane.showMessageDialog(null, "No option selected. Exiting program.");
                    option = 10; // Force exit loop
                }
            }
        } while (option != 10);
    }
}