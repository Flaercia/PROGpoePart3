/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.progpoe02;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class MainTest {

    @BeforeAll
    public static void setUpClass() {
        // Code to run before all tests
    }

    @AfterAll
    public static void tearDownClass() {
        // Code to run after all tests
    }

    @BeforeEach
    public void setUp() {
        // Code to run before each test
    }

    @AfterEach
    public void tearDown() {
        // Code to run after each test
    }

    @Test
    public void testMain() {
        String[] args = null;
        // Ensure that the main method runs without throwing exceptions
        assertDoesNotThrow(() -> Main.main(args));
    }
}
