/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.progpoe02;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testCheckMessageID() {
        Message msg = new Message();
        msg.id = ""; 
        assertFalse(msg.checkMessageID());

        msg.id = "ID123";
        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testCheckRecipientCell() {
        Message msg = new Message();
        msg.recipient = "12345";
        assertFalse(msg.checkRecipientCell());

        msg.recipient = "+27834557896";
        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testCheckMessageLength() {
        Message msg = new Message();
        msg.text = "Short message";
        assertEquals("Message ready to send.", msg.checkMessageLength());

        String longText = "a".repeat(251);
        msg.text = longText;
        assertEquals("Message too long!", msg.checkMessageLength());
    }

    @Test
    public void testSentMessage() {
        Message msg = new Message();
        msg.recipient = "+27834557896";
        assertEquals("sent", msg.SentMessage());

        msg.recipient = "invalid";
        assertEquals("discarded", msg.SentMessage());
    }

   
}
